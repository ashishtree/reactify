import React from "react";
import PostList from "../containers/post-list";
require("../../scss/style.scss");

const App = () => (
  <div>
    <PostList />
  </div>
);

export default App;
